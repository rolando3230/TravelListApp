class UserPost {
  final String id;
  final String trailname;
  final String location;
  final String description;
  final String trailduration;
  final String traildistance;
  final String trailtype;
  final String image;

  UserPost({
    required this.id,
    required this.trailname,
    required this.location,
    required this.description,
    required this.trailduration,
    required this.traildistance,
    required this.trailtype,
    required this.image,
  }); 

  Map<String, dynamic> toJson() => {
        'id': id,
        'trailname': trailname,
        'location': location,
        'description': description,
        'trailduration': trailduration,
        'traildistance': traildistance,
        'trailtype': trailtype,
        'image': image,
      };

  static UserPost fromJson(Map<String, dynamic> json) => UserPost(
        id: json['id'],
        trailname: json['trailname'],
        location: json['location'],
        description: json['description'],
        trailduration: json['trailduration'],
        traildistance: json['traildistance'], 
        trailtype: json['trailtype'],
        image: json['image'],

      );
}
