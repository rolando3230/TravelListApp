  import 'dart:ui';

import 'package:firebase_auth/firebase_auth.dart';
  import 'package:flutter/material.dart';
  import 'package:huhu/main.dart';
  import 'package:huhu/pracadd.dart';

  class Login extends StatefulWidget {
    const Login({super.key});

    @override
    State<Login> createState() => _LoginState();
  }

  class _LoginState extends State<Login> {
    late TextEditingController usernamecontroller;
    late TextEditingController passwordcontroller;
    late String error;

    @override
    void initState() {
      super.initState();
      usernamecontroller = TextEditingController();
      passwordcontroller = TextEditingController();
      error = "";
    }

    @override
    void dispose() {
      usernamecontroller.dispose();
      passwordcontroller.dispose();
      super.dispose();
    }

    @override
    Widget build(BuildContext context) {
      return Scaffold(
        backgroundColor: Colors.grey.shade300,
        body: SafeArea(
          child: Center(
            child: ListView(
              children: [
                Center(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 30),
                    child: Column(

                      children: [
                        const Icon(Icons.android,size: 120,),
                    const SizedBox(height:25),
                    const Text('Hello Again',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 38,
                      )
                    ),
                    const SizedBox(height: 40,),
                    const Text('Welcome back, you\'ve been missed!',
                    style: TextStyle( 
                      fontSize: 20,
                      ),
                    ),
                        const SizedBox(
                          height: 20,
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 10,
                          ),
                          child: TextField(
                            controller: usernamecontroller,
                            decoration: const InputDecoration(
                              border: OutlineInputBorder(),
                              labelText: 'Enter Email',
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 10,
                          ),
                          child: TextField(
                            controller: passwordcontroller,
                            obscureText: true,
                            decoration: const InputDecoration(
                              border: OutlineInputBorder(),
                              labelText: 'Enter password',
                            ),
                          ),
                        ),
                        Container(
                    padding: const EdgeInsets.all(20),
                    child: ElevatedButton(
                      onPressed: () {
                        bool flag = true;
                        if(passwordcontroller.text == ""){
                          flag = false;
                          }
                          if (flag) {
                              if(usernamecontroller.text == ""){
                          flag = false;
                          
                        }
                            signIn();
                        }
                        else{
                          showDialog(context: context, builder: (context){
                            return  AlertDialog(
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.all(Radius.circular(32))
                              ),
                              backgroundColor: const Color(0XFFC72C41),
                              content: Container(
                                padding: const EdgeInsets.all(16),
                                height: 90,
                                decoration: const BoxDecoration(
                                  color: Color(0xFFC72C41),
      
                                ),
                                child: Row(
                                  children: [
                                      const Icon(Icons.info,
                                      color: Colors.white,
                                      size: 50,),
                                    Row(                                  
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children:  [
                                        Padding(
                                          padding: const EdgeInsets.only(left: 20),
                                          child: Column(
                                            children: const [
                                              Text("Oh Snap!",style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 15,
                                              fontWeight: FontWeight.bold
                                                                  ),),
                                                                  
                                                              Text('Something Went Wrong',
                                                              style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 10,
                                                              ),
                                                              maxLines: 2,
                                                              overflow: TextOverflow.ellipsis,
                                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),);
                          },
                          );
                        }
                        setState(() {});
                      },
                      style: ElevatedButton.styleFrom(
                          minimumSize: const Size.fromHeight(50),
                          backgroundColor: Colors.deepPurple),
                      child: const Text(
                        'LOGIN',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: TextButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => const PracAdd(),
                                  ),
                                );
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  Text('Not a member?',
                                  style: TextStyle(
                                    
                                    color: Colors.grey,
                                    fontWeight: FontWeight.bold
                                    ),
                                  ),
                                  Text(' Register Now',
                        style: TextStyle(
                        
                          fontWeight: FontWeight.bold,
                          color: Colors.blue
                        ),)
                                ],
                              )),
                        ),
                        Container(
                          padding: const EdgeInsets.all(20),
                          child: Text(
                            error,
                            style: const TextStyle(
                              color: Colors.red,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    Future signIn() async {
      try {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: usernamecontroller.text.trim(),
          password: passwordcontroller.text.trim(),
        );
          showDialog(
          context: context,
          builder: (context)=> AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            title: const Text('Welcome', style: TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.bold,
              color: Colors.deepPurple
            ),),
            content: const Text('You have  successfully logged in',
            style: TextStyle(
              fontSize: 25,
              fontWeight: FontWeight.bold,
              color: Colors.deepPurple
            ),),
            actions: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  primary: Colors.deepPurple
                ),
                onPressed:(){
                  Navigator.pushAndRemoveUntil<dynamic>(
                  context, MaterialPageRoute<dynamic>
                ( builder: (BuildContext context) => const MainPage(),
                  ),
                  (route) => false,
                  );
                },
                child: Text('Proceed', style: TextStyle(
                  fontWeight: FontWeight.bold
                ),),
                )
            ],
          )
          );
    
        setState(() {
          error = "";
        });
      } on FirebaseAuthException catch (e) {
        print(e);
        setState(() {
          error = e.message.toString();
        });
        
      }
    
    }
  }
