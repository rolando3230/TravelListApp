import 'dart:io';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:huhu/user1.dart';
import 'package:quickalert/models/quickalert_type.dart';
import 'package:quickalert/widgets/quickalert_dialog.dart';



class PracUpdate extends StatefulWidget {
  const PracUpdate({
    super.key,
    required this.user,
  });

  final Users1 user;

  @override
  State<PracUpdate> createState() => _PracUpdateState();
}

class _PracUpdateState extends State<PracUpdate> {
  late TextEditingController lastnamecontroller;
  late TextEditingController phonenumcontroller;
  late TextEditingController passwordcontroller;
  late TextEditingController firstnamecontroller;
  late TextEditingController gendercontroller;
  late TextEditingController addresscontroller;
  late TextEditingController emailcontroller;
  late TextEditingController birthdaycontroller;
  late String imgUrl;
  late String error;
  PlatformFile? pickedFile;
  UploadTask? uploadTask;

  Future selectFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result == null) return;

    setState(() {
      pickedFile = result.files.first;
    });
   
  }

  String generateRandomString(int len) {
    var r = Random();
    const _chars =
        'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';
    return List.generate(len, (index) => _chars[r.nextInt(_chars.length)])
        .join();
  }

  Future uploadFile() async {
    final path = 'files/${generateRandomString(8)}';
    print('update path Link: $path');
    final file = File(pickedFile!.path!);

    final ref = FirebaseStorage.instance.ref().child(path);

    try {
      setState(() {
        uploadTask = ref.putFile(file);
      });
    } on FirebaseException catch (e) {
      setState(() {
        error = e.message.toString();
      });
    }

    final snapshot = await uploadTask!.whenComplete(() {});
    final urlDownload = await snapshot.ref.getDownloadURL();
    print('update Download Link: $urlDownload');

    updateUser(widget.user.id, urlDownload);
    

    setState(() {
      uploadTask = null;
    });
  }

  @override
  void initState() {
    super.initState();
    lastnamecontroller = TextEditingController(
      text: widget.user.lastname  ,
    );
    phonenumcontroller = TextEditingController(
      text: widget.user.phonenum,
    );
    passwordcontroller = TextEditingController(
      text: widget.user.password,
    );
    firstnamecontroller = TextEditingController(
      text: widget.user.firstname,
    );
     gendercontroller = TextEditingController(
      text: widget.user.gender,
    );
     addresscontroller = TextEditingController(
      text: widget.user.address,
    );
     emailcontroller = TextEditingController(
      text: widget.user.email,
    );
     birthdaycontroller = TextEditingController(
      text: widget.user.birthday,
    );
    
    imgUrl = widget.user.image;
    error = "";
  }

  @override
  void dispose() {
    lastnamecontroller.dispose();
    phonenumcontroller.dispose();
    passwordcontroller.dispose();
    firstnamecontroller.dispose();
    gendercontroller.dispose();
    addresscontroller.dispose();
    emailcontroller.dispose();
    birthdaycontroller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: const Text('Update Hiker\'s Account', 
        style: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.bold
        ),),
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            size: 35,
            Icons.arrow_back,
          ),
        ),
      ),
      backgroundColor: Colors.grey.shade300,
      body: ListView(
        children: [
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(
                  height: 20,
                ),
                Container(
                  margin: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    border: Border.all(
                      width: 2,
                      color: Color.fromARGB(142, 158, 158, 158),
                    ),
                  ),
                  child: Center(
                    child: (pickedFile == null) ? checkImgVal() : imgExist(),
                  ),
                ),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple),
                  onPressed: () {
                    selectFile();
                  },
                  icon: const Icon(Icons.camera),
                  label: const Text('Add Photo'),
                ),
                const SizedBox(
                  height: 20,
                ),
                 Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: firstnamecontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.person_add,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Firstname',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                 Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: lastnamecontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.person_add,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Lastname ',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                 Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: addresscontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.location_on_rounded,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Address',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                 Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: gendercontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.transgender,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Gender',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                  Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: birthdaycontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.cake,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Birthday',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                  Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: phonenumcontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.phone_iphone_outlined,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Phone Number',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                  Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: emailcontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.email,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Email',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                Container(
                  width: double.infinity,
                  height: 90,
                  padding: const EdgeInsets.all(20),
                  child: ElevatedButton(

                    onPressed: () {
                      (pickedFile != null)
                          ? uploadFile()
                          : updateNoFile(widget.user.id);
                         
                    },
                     style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.deepPurple),
  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
    RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(200 ),
      side: BorderSide(color: Colors.deepPurple),
    )
  )
),
                    child: const Text(
                      'Update',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(20),
                  child: Text(
                    error,
                    style: const TextStyle(
                      color: Colors.red,
                    ),
                  ),
                ),
                buildProgress(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future updateUser(String id, String image) async {
    final docUser = FirebaseFirestore.instance.collection('PracUser').doc(id);
    await docUser.update({
      'firstname': firstnamecontroller.text,
      'lastname': lastnamecontroller.text,
      'phonenum': phonenumcontroller.text,
      'password': passwordcontroller.text,
      'address': addresscontroller.text,
      'email': emailcontroller.text,
      'gender': gendercontroller.text,
      'birthday': birthdaycontroller.text,
      'image': image,
    });
    QuickAlert.show(
                        context: context,
                        type: QuickAlertType.success,
                         text: 'Edited  Successfully',
                         backgroundColor: Colors.deepPurple
                            );

 
  }

  Future updateNoFile(String id) async {
    final docUser = FirebaseFirestore.instance.collection('PracUser').doc(id);
    await docUser.update({
     'firstname': firstnamecontroller.text, 
      'lastname': lastnamecontroller.text,
      'phonenum': phonenumcontroller.text,
      'password': passwordcontroller.text,
      'address': addresscontroller.text,
      'email': emailcontroller.text,
      'gender': gendercontroller.text,
      'birthday': birthdaycontroller.text,
    });
      QuickAlert.show(
                        context: context,
                        type: QuickAlertType.success,
                         text: 'Edited Successfully!',
                         backgroundColor: Colors.deepPurple
                            );
    

   
  }

  Widget imgExist() => Image.file(
        File(pickedFile!.path!),
        width: double.infinity,
        height: 250,
        fit: BoxFit.cover,
      );

  Widget imgNotExist() => Image.network(
        widget.user.image,
        width: double.infinity,
        height: 250,
        fit: BoxFit.cover,
      );

  Widget imgNotExistBlank() => Image.asset(
        'assets/images/no-image.png',
        width: double.infinity,
        height: 250,
        fit: BoxFit.cover,
      );

  Widget checkImgVal() {
    return (widget.user.image == '-') ? imgNotExistBlank() : imgNotExist();
  }

  Widget buildProgress() => StreamBuilder<TaskSnapshot>(
      stream: uploadTask?.snapshotEvents,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          final data = snapshot.data!;
          double progress = data.bytesTransferred / data.totalBytes;

          return SizedBox(
            height: 50,
            child: Stack(
              fit: StackFit.expand,
              children: [
                LinearProgressIndicator(
                  value: progress,
                  backgroundColor: Colors.grey,
                  color: Colors.deepPurple,
                ),
                Center(
                  child: Text(
                    '${(100 * progress).roundToDouble()}%',
                    style: const TextStyle(
                      color: Colors.white,
                    ),
                  ),
                )
              ],
            ),
          );
        } else {
          return const SizedBox(
            height: 50,
          );
        }
      });
}
