import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:huhu/homescreen.dart';
import 'package:huhu/pracUpdate.dart';
import 'package:huhu/pracadd.dart';
import 'package:huhu/user1.dart';

class Accountdetails extends StatefulWidget {
  const Accountdetails({super.key});

  @override
  State<Accountdetails> createState() => _AccountdetailsState();
}

class _AccountdetailsState extends State<Accountdetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: const Text(
          ' Hiker\'s Information',
          style: TextStyle(
            fontSize: 28,
          ),
        ),
        leading: IconButton(
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => const Homescreen()));
          },
          icon: const Icon(
            Icons.arrow_back,
            size: 30,
          ),
        ),
      ),
      backgroundColor: Colors.grey,
      body: StreamBuilder<List<Users1>>(
        stream: readUsers1(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Text('Something went wrong! ${snapshot.error}');
          } else if (snapshot.hasData) {
            final user1 = snapshot.data!;

            return ListView(
              children: user1.map(newuser1).toList(),
            );
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }

  Widget newuser1(Users1 users1) => GestureDetector(
        onTap: () {},
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            const SizedBox(
              height: 15,
            ),
            buildQouteCard(users1),
          ],
        ),
      );
  Widget buildQouteCard(Users1 user1){ 
    final user = FirebaseAuth.instance.currentUser!;
    return Card(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              color: Colors.grey.shade400,
              height: 400,
              width: 400,
              child: Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    CircleAvatar(
                        radius: (52),
                        backgroundColor: Colors.white,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(50),
                          child: Image.network(user1.image,
                              width: 100, height: 100, fit: BoxFit.cover),
                        )),
                    const SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(left: 8),
                          child: Text(
                            'Name: ',
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.deepPurple,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        SafeArea(
                          child: Text(
                            user1.firstname,
                            style: const TextStyle(
                              fontSize: 18,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(
                            user1.lastname,
                            style: const TextStyle(
                              fontSize: 18,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    SafeArea(
                      child: Row(
                        children: [
                          const Padding(
                            padding: EdgeInsets.only(left: 8),
                            child: Text(
                              'Address: ',
                              maxLines: 3,
                              overflow: TextOverflow.fade,
                              style: TextStyle(
                                fontSize: 20,
                                color: Colors.deepPurple,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SafeArea(
                            child: Text(
                              user1.address,
                              style: const TextStyle(
                                fontSize: 18,
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Row(
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(left: 8.0),
                          child: Text(
                            'Gender: ',
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.deepPurple,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        SafeArea(
                          child: Text(
                            user1.gender,
                            style: const TextStyle(
                              fontSize: 18,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Row(
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(left: 8.0),
                          child: SafeArea(
                            child: Expanded(
                              child: Text(
                                'Enter Email:',
                                style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.deepPurple,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                        SafeArea(
                          child: Expanded(
                            child: Text(
                              user1.email,
                              style: const TextStyle(
                                fontSize: 18,
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Row(
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(left: 8.0),
                          child: Text(
                            'Phone Number: ',
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.deepPurple,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        SafeArea(
                          child: Text(
                            user1.phonenum,
                            style: const TextStyle(
                              fontSize: 18,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Row(
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(left: 8.0),
                          child: Text(
                            'Birthday: ',
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.deepPurple,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        SafeArea(
                          child: Text(
                            user1.birthday,
                            style: const TextStyle(
                              fontSize: 18,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        (user.email == user1.email) ?
                        IconButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => PracUpdate(user: user1),
                              ),
                            );
                          },
                          icon: const Icon(
                            Icons.edit,
                            color: Colors.deepPurple,
                          ),
                        ): const SizedBox(),
                        (user.email == user1.email) ?
                        IconButton(
                          color: Colors.deepPurple,
                          onPressed: () {
                            _showActionSheet(context, user1.id);
                          },
                          icon: const Icon(
                            Icons.delete,
                            color: Colors.deepPurple,
                          ),
                        ) : const SizedBox(),
                      
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );}

  void _showActionSheet(BuildContext context, String id) {
    showCupertinoModalPopup(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        title: const Text(
          'Confirmation',
          style: TextStyle(
              color: Colors.red, fontWeight: FontWeight.bold, fontSize: 30),
        ),
        message: const Text(
          'Are you sure you want to delete this Account? Doing this will permanently Eradicate this Data.',
          style: TextStyle(
            color: Colors.red,
            fontWeight: FontWeight.bold,
            fontSize: 25,
          ),
        ),
        actions: [
          CupertinoActionSheetAction(
            onPressed: () {
              deleteUser1(id);
            },
            child: const Text(
              'Continue',
              style: TextStyle(
                color: Colors.deepPurple,
              ),
            ),
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          child: const Text(
            'Cancel',
            style: TextStyle(color: Colors.deepPurple),
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
    );
  }

  var nametxtStyle = const TextStyle(
    fontWeight: FontWeight.bold,
    color: Colors.deepPurple,
    fontSize: 18,
  );

  Stream<List<Users1>> readUsers1() =>
      FirebaseFirestore.instance.collection('PracUser').snapshots().map(
            (snapshot) => snapshot.docs
                .map(
                  (doc) => Users1.fromJson(
                    doc.data(),
                  ),
                )
                .toList(),
          );
  deleteUser1(String id) {
    final docUser = FirebaseFirestore.instance.collection('PracUser').doc(id);
    docUser.delete();
    showDialog(
        context: context,
        builder: (context) => AlertDialog(
              title: const Text('Hiker Account'),
              content: const Text('Is Successfully Deleted'),
              actions: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(primary: Colors.deepPurple),
                  onPressed: () {
                    Navigator.pushAndRemoveUntil<dynamic>(
                      context,
                      MaterialPageRoute<dynamic>(
                        builder: (BuildContext context) =>
                            const Accountdetails(),
                      ),
                      (route) => false,
                    );
                  },
                  child: Text('Okay'),
                )
              ],
            ));
  }
}
