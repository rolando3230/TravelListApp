class Users1 {
  final String id;
  final String lastname;
  final String phonenum;
  final String password;
  final String firstname;
  final String gender;
  final String address;
  final String email;
  final String birthday;
  final String image;

  Users1({
    required this.id,
    required this.lastname,
    required this.phonenum,
    required this.password,
    required this.firstname,
    required this.gender,
    required this.address,
    required this.email,
    required this.birthday,
    required this.image,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'phonenum': phonenum,
        'password': password,
        'lastname': lastname,
        'firstname': firstname,
        'gender': gender,
        'address': address,
        'email': email,
        'birthday': birthday,
        'image': image,
      };

  static Users1 fromJson(Map<String, dynamic> json) => Users1(
        id: json['id'],
        lastname: json['lastname'],
        phonenum: json['phonenum'],
        password: json['password'],
        firstname: json['firstname'],
        gender: json['gender'],
        address: json['address'],
        email: json['email'], 
        birthday: json['birthday'],
        image: json['image']
      );
      
}
