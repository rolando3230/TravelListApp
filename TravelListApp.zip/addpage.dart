import 'dart:io';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';

import 'package:flutter/material.dart';
import 'package:huhu/additem.dart';
import 'package:quickalert/models/quickalert_type.dart';
import 'package:quickalert/widgets/quickalert_dialog.dart';

class Addpage extends StatefulWidget {
  const Addpage({super.key});

  @override
  State<Addpage> createState() => _AddpageState();
}

class _AddpageState extends State<Addpage> {
  late TextEditingController trailnameCtrl;
  late TextEditingController locationCtrl;
  late TextEditingController descriptionCtrl;
  late TextEditingController traildurationCtrl;
  late TextEditingController traildistanceCtrl;
  late TextEditingController trailtypeCtrl;
  PlatformFile? pickedFile;
  UploadTask? uploadTask;
  late String error;
  
  Future selectFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result == null) return;

    setState(() {
      pickedFile = result.files.first;
    });
  }

  String generateRandomString(int len) {
    var r = Random();
    const _chars =
        'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';
    return List.generate(len, (index) => _chars[r.nextInt(_chars.length)])
        .join();
  }

  Future uploadFile() async { 
    final path = 'files/${generateRandomString(5)}';
    final file = File(pickedFile!.path!);

    final ref = FirebaseStorage.instance.ref().child(path);

    setState(() {
      uploadTask = ref.putFile(file);
    });

    final snapshot = await uploadTask!.whenComplete(() {});
    final urlDownload = await snapshot.ref.getDownloadURL();
    print('Download Link: $urlDownload');

    createUser(urlDownload);

    setState(() {
      uploadTask = null;
    });
      QuickAlert.show(
        context: context,
        backgroundColor: Colors.deepPurple,
        type: QuickAlertType.success,
        text: 'Added Successfully!',
      );
  }

  @override
  void initState() {
    super.initState();
    trailnameCtrl = TextEditingController();
    locationCtrl = TextEditingController();
    descriptionCtrl = TextEditingController();
    traildurationCtrl = TextEditingController();
    traildistanceCtrl = TextEditingController();
    trailtypeCtrl = TextEditingController();
    error = "";
  
  }

  @override
  void dispose() {
    trailnameCtrl.dispose();
    locationCtrl.dispose();
    descriptionCtrl.dispose();
    traildurationCtrl.dispose();
    traildistanceCtrl.dispose();
    trailtypeCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: const Padding(
          padding: EdgeInsets.only(left: 26),
          child: Text('Add New Trail ', style: TextStyle(
            fontSize: 30, fontWeight: FontWeight.bold,
          ),),
        ),
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
          ),
        ),
      ),
      backgroundColor: Colors.grey.shade300,
      body: ListView(
        children: [
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(
                  height: 20, 
                ),
                Container(
                  margin: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    border: Border.all(
                      width: 2,
                      color: Color.fromARGB(142, 158, 158, 158),
                    ),
                  ),
                  child: Center(
                    child: (pickedFile == null) ? imgNotExist() : imgExist(),
                  ),
                ),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple),
                  onPressed: () {
                    selectFile();
                  },
                  icon: const Icon(Icons.add_a_photo),
                  label: const Text('Add Photo'),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    maxLines: 10,
                    controller: descriptionCtrl,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.description,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Trail Description',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
               Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: traildurationCtrl,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.mobile_friendly,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Trail Duration',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
               Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: traildistanceCtrl,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.map,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Trail Distance',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: trailnameCtrl,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.hiking,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Trail Name',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
              Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: locationCtrl,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.location_on_sharp,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Trail Location',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
               Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: trailtypeCtrl,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.type_specimen_outlined,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Trail Type',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                Container(
                    width: double.infinity,
                    height: 100,
                  padding: const EdgeInsets.all(20),
                  child: ElevatedButton(
                    onPressed: () {
                      bool flag = true;
                      if (trailnameCtrl.text == "") {
                         flag = false;
                      }
                      if(locationCtrl.text == ""){
                        flag = false;
                        }
                        if (flag) {
                            if(descriptionCtrl.text == ""){
                        flag = false;
                          if(trailtypeCtrl.text == ""){
                        flag = false;
                         
                      }
                      }
                	        
                          uploadFile();
                          error;
                      }
                      else{
                        showDialog(context: context, builder: (context){
                          return  AlertDialog(
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(32))
                            ),
                            backgroundColor: const Color(0XFFC72C41),
                            content: Container(
                              padding: const EdgeInsets.all(16),
                              height: 90,
                              decoration: const BoxDecoration(
                                color: Color(0xFFC72C41),
    
                              ),
                              child: Row(
                                children: [
                                     const Icon(Icons.info,
                                     color: Colors.white,
                                     size: 50,),
                                  Row(                                  
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children:  [
                                      Padding(
                                        padding: const EdgeInsets.only(left: 20),
                                        child: Column(
                                          children: const [
                                            Text("Oh Snap!",style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold
                                                                ),),
                                                                
                                                            Text('Something Went Wrong',
                                                            style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                                            ),
                                                            maxLines: 2,
                                                            overflow: TextOverflow.ellipsis,
                                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),);
                        },
                        );
                      }
                      setState(() {});
                    },
                    style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.deepPurple),
  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
    RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(200 ),
      side: BorderSide(color: Colors.deepPurple),
    )
  )
),
                    child: const Text(
                      'Add Trail ',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                 buildProgress(),
              ],
            ),
          ),
        ],
      ),
    );
  }
   Widget imgExist() => Image.file(
        File(pickedFile!.path!),
        width: double.infinity,
        fit: BoxFit.cover,
        
      );

  Widget imgNotExist() => Image.asset(
        'assets/images/default.png',
        fit: BoxFit.cover,
      );
  Future createUser(urlDownload) async {
    final docUser = FirebaseFirestore.instance.collection('UserPost').doc();

    final newPost = UserPost(
      id: docUser.id,
      trailname: trailnameCtrl.text,
      location: locationCtrl.text,
      description: descriptionCtrl.text,
      trailduration: traildurationCtrl.text,
      traildistance: traildistanceCtrl.text, 
      trailtype: trailtypeCtrl.text,
      image: urlDownload
    );

    final json = newPost.toJson();
    await docUser.set(json);

    setState(() {
      trailnameCtrl.text = "";
      locationCtrl.text = "";
      descriptionCtrl.text = "";
      traildurationCtrl.text = "";
      traildistanceCtrl.text = "";
      trailtypeCtrl.text = "";
      pickedFile = null;
  
    });
     

  }
  Widget buildProgress() => StreamBuilder<TaskSnapshot>(
      stream: uploadTask?.snapshotEvents,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          final data = snapshot.data!;
          double progress = data.bytesTransferred / data.totalBytes;

          return SizedBox(
            height: 50,
            child: Stack(
              fit: StackFit.expand,
              children: [
                LinearProgressIndicator(
                  value: progress,
                  backgroundColor: Colors.grey,
                  color: Colors.deepPurple,
                ),
                Center(
                  child: Text(
                    '${(100 * progress).roundToDouble()}%',
                    style: const TextStyle(
                      color: Colors.white,
                    ),
                  ),
                )
              ],
            ),
          );
        } else {
          return const SizedBox(
            height: 50,
          );
        }
      }
      );
    
      
}
