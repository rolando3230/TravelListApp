
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:huhu/accountdetail.dart';
import 'package:huhu/additem.dart';
import 'package:huhu/addpage.dart';
import 'package:huhu/end.dart';
import 'package:huhu/updatetrail.dart';
class Homescreen extends StatefulWidget {
  const Homescreen({super.key});

  @override
  State<Homescreen> createState() => _HomescreenState();
}

class _HomescreenState extends State<Homescreen> {
  TextEditingController _searchController = TextEditingController();
  
 @override
 void initState(){
  super.initState();
  _searchController.addListener(_onSearchChanged);
 }
 @override
 void dispose(){
  _searchController.removeListener(_onSearchChanged);
  _searchController.dispose();
  super.dispose();
 }

 _onSearchChanged(){
  print(_searchController.text);

 }
 

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: const Text('Davao Trail List', style: TextStyle(
          fontSize: 23,
        ),),
        actions: [
           IconButton(
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context)
            => const Accountdetails()));
          },
          icon: const Icon(
          Icons.account_box,
          size: 30,),
        ),
        IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const Addpage(),
                ),
              );
            },
            icon: const Icon(Icons.add_circle,size: 25,),
          ),
           Column(
             children: [
               Padding(
                 padding: const EdgeInsets.only(top: 5),
                 child: IconButton(
          onPressed: () {
                  FirebaseAuth.instance.signOut();
          },
          icon: const Icon(Icons.logout_sharp,
          size: 25,),
        ),
               ),
    
             ],
           ),
           
        ],
        leading: IconButton(
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context)
            => const hehe()));
          },
          icon: const Icon(
          Icons.hiking,
          size: 30,),
        ),  
      ),
      backgroundColor: Colors.grey,
      
      body: StreamBuilder<List<UserPost>>(
        stream: readUserPost(),
        builder: (context, snapshot) {
      if (snapshot.hasError) {
        return Text('Something went wrong! ${snapshot.error}');
      } else if (snapshot.hasData) {
        final users = snapshot.data!;
        return ListView(
          
          children: users.map(newuserpost).toList(),
        );
      } else {
        return const Center(
          child: CircularProgressIndicator(),
        );
      }
        },
      )
      
    );
  }
  

  Widget newuserpost(UserPost userpost) => GestureDetector(
        onTap: () {},
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            const SizedBox(
              height: 15,
            ),
            buildTitle(userpost),
            buildImageCard(userpost),
            buildQouteCard(userpost),
            
          ],
        ),
      );

 Widget buildImageCard(UserPost userpost) => Card(
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Ink.image(image: NetworkImage(userpost.image),
            height: 240,
            fit: BoxFit.cover,
            ),
            Positioned(
              bottom: 16,
              right: 16,
              left: 16,
              child: 
              Row(
                children: [
                  const Icon(Icons.location_on, 
                  color: Colors.orange,
                  size: 25,
                  ),
                  Text(userpost.location, 
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 25,
                  ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

      Widget buildQouteCard(UserPost userpost) => Card(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children:  [
            Container(
              color: Colors.grey.shade400,
              height: 300,
              width: 400,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [ 
                  Row(
                    children: const [
                      SafeArea(
                        child: Padding(
                          padding: EdgeInsets.only(top:15,left: 10),
                          child: Text('Trail Description: ',
                          style: TextStyle(
                            fontSize: 20,
                            color: Colors.deepPurple,
                            fontWeight: FontWeight.bold,
                             ),
                             ),
                        ),
                      ),
                    ],
                  ),
                   Padding(
                      padding: const EdgeInsets.only(left: 16),
                     child: SafeArea(
                       child: Text(
                         userpost.description,
                         style: const TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                         ),
                                       ),
                     ),
                   ),
                  const SizedBox(
                    height: 10,
                  ),
                      Row(
                        children: [
                          const Padding(
                            padding: EdgeInsets.only(left: 10),
                            child: Text('Trail Duration: ',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.deepPurple,
                    fontWeight: FontWeight.bold,
                     ),
                     ),
                          ),
                         SafeArea(
                           child: Text(
                                              userpost.trailduration,
                                              style: const TextStyle(
                                               fontSize: 18,
                                               color: Colors.white,
                                               fontWeight: FontWeight.bold,
                                              ),
                                           ),
                         ),
                        ],
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          const Padding(
                             padding: EdgeInsets.only(left: 10),
                            child: Text('Trail Type: ',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.deepPurple,
                    fontWeight: FontWeight.bold,
                     ),
                     ),
                          ),
                         SafeArea(
                           child: Text(
                                              userpost.trailtype,
                                              style: const TextStyle(
                                               fontSize: 18,
                                               color: Colors.white,
                                               fontWeight: FontWeight.bold,
                                              ),
                                           ),
                         ),
                        ],
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                     Row(
                        children: [
                          const Padding(
                            padding: EdgeInsets.only(left: 10),
                            child: Text('Trail Distance: ',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.deepPurple,
                    fontWeight: FontWeight.bold,
                     ),
                     ),
                          ),
                         SafeArea(
                           child: Text(
                                              userpost.traildistance,
                                              style: const TextStyle(
                                               fontSize: 18,
                                               color: Colors.white,
                                               fontWeight: FontWeight.bold,
                                              ),
                                           ),
                         ),
                        ],
                      ),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              IconButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => UpdateTrail(user : userpost),
                    ),
                  );
                },
                icon: const Icon(Icons.edit,color: Colors.deepPurple,)), IconButton(
                  color: Colors.deepPurple,
                onPressed: () {
                  _showActionSheet(context, userpost.id);
                },
                icon: const Icon(Icons.delete,color: Colors.deepPurple,))
                            ],
                          ),
                ],
              ),
            ),
            
          ],
          
        ),
      );

    Widget buildTitle(UserPost userpost) => Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Trail Name:', style: TextStyle(
               fontSize: 30,
               color: Colors.deepPurple
            ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 5),
              child: SafeArea(
                child: Text( userpost.trailname,
                style: const TextStyle(
                  fontSize: 25,
                  color: Colors.white
                ),
                ),
              ),
            ),  
          ],

        ),
      ],
      );
       void _showActionSheet(BuildContext context, String id) {
    showCupertinoModalPopup(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        title: const Text('Confirmation',style: TextStyle(
          color: Colors.red,
          fontSize: 30
        ),),
        message: const Text(
            'Are you sure you want to delete this Trail? Doing this will permanently delete the data.', style: TextStyle(color:Colors.red,fontSize: 25),),
        actions: [
          CupertinoActionSheetAction(
            onPressed: () {
              deleteUser(id);
            },
            child: const Text('Continue'),
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          child: const Text('Cancel'),
          onPressed: () => Navigator.pop(context),
        ),
      ),
    );
  }

  Stream<List<UserPost>> readUserPost() =>
      FirebaseFirestore.instance.collection('UserPost').snapshots().map(
            (snapshot) => snapshot.docs
                .map(
                  (doc) => UserPost.fromJson(
                    doc.data(),
                  ),
                )
                .toList(),
          );
  deleteUser(String id) {
    final docUser = FirebaseFirestore.instance.collection('UserPost').doc(id);
    docUser.delete();
     showDialog(
        context: context,
         builder: (context)=> AlertDialog(
          title: const Text('Trail List'),
          content: const Text('Are Successfully Deleted'),
          actions: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: Colors.deepPurple
              ),
              onPressed:(){
                Navigator.pushAndRemoveUntil<dynamic>(
                context, MaterialPageRoute<dynamic>
               ( builder: (BuildContext context) => const Homescreen(),
                ),
                (route) => false,
                );
              },
              child: const Text('Okay'),
              )
          ],
         )
         );
   

  }
}







