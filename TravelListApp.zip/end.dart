

import 'package:flutter/material.dart';
import 'package:huhu/homescreen.dart';

class hehe extends StatelessWidget {
  const hehe({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
          children: const [Padding(
            padding: EdgeInsets.only(top: 230),
            child: SafeArea(
              child: Text('That\'s All For My Presentation, Thank you! Cliff Sama.', style: TextStyle(
                fontSize: 50,
              ),
              ),
            ),
          )],
          ),
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const Homescreen(),
                ),
              );
            },
            icon: const Icon(Icons.arrow_back),
          ),
        ],
      ),
    );
  }
}