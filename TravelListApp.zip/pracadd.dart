import 'dart:io';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:huhu/login.dart';
import 'package:huhu/main.dart';
import 'package:huhu/user1.dart';
import 'package:quickalert/models/quickalert_type.dart';
import 'package:quickalert/widgets/quickalert_dialog.dart';


class PracAdd extends StatefulWidget {
  const PracAdd({super.key});

  @override
  State<PracAdd> createState() => _PracAddState();
}

class _PracAddState extends State<PracAdd> {
  late TextEditingController lastnamecontroller;
  late TextEditingController phonenumcontroller;
  late TextEditingController passwordcontroller;
  late TextEditingController firstnamecontroller;
  late TextEditingController gendercontroller;
  late TextEditingController addresscontroller;
  late TextEditingController emailcontroller;
  late TextEditingController birthdaycontroller;
  late String error;
  PlatformFile? pickedFile;
  UploadTask? uploadTask;

  Future selectFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result == null) return;

    setState(() {
      pickedFile = result.files.first;
    });
  }

  String generateRandomString(int len) {
    var r = Random();
    const _chars =
        'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';
    return List.generate(len, (index) => _chars[r.nextInt(_chars.length)])
        .join();
  }

  Future uploadFile() async {
    final path = 'files/${generateRandomString(5)}';
    final file = File(pickedFile!.path!);

    final ref = FirebaseStorage.instance.ref().child(path);

    setState(() {
      uploadTask = ref.putFile(file);
    });

    final snapshot = await uploadTask!.whenComplete(() {});
    final urlDownload = await snapshot.ref.getDownloadURL();
    print('Download Link: $urlDownload');

    createUser(urlDownload);

    setState(() {
      uploadTask = null;
    });
     QuickAlert.show(
        context: context,
        backgroundColor: Colors.deepPurple,
        type: QuickAlertType.success,
        text: 'Added Successfully!',
      );
  }

  @override
  void initState() {
    super.initState();
    lastnamecontroller = TextEditingController();
    phonenumcontroller = TextEditingController();
    passwordcontroller = TextEditingController();
    firstnamecontroller = TextEditingController();
    gendercontroller = TextEditingController();
    addresscontroller = TextEditingController();
    emailcontroller = TextEditingController();
    birthdaycontroller = TextEditingController();

  }

  @override
  void dispose() {
    lastnamecontroller.dispose();
    phonenumcontroller.dispose();
    passwordcontroller.dispose();
    firstnamecontroller.dispose();
    gendercontroller.dispose();
    addresscontroller.dispose();
    emailcontroller.dispose();
    birthdaycontroller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: const Padding(
          padding: EdgeInsets.only(left: 44),
          child: Text('Create Hiker\'s Account',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),),
        ),
        leading: Padding(
          padding: const EdgeInsets.only(left: 25),
          child: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(
              Icons.arrow_back,
            ),
          ),
        ),
      ),
      backgroundColor: Colors.grey.shade300,
      body: ListView(
        children: [
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(
                  height: 20,
                ),
                Container(
                  margin: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    border: Border.all(
                      width: 2,
                      color: Color.fromARGB(142, 158, 158, 158),
                    ),
                  ),
                  child: Center(
                    child: (pickedFile == null) ? imgNotExist() : imgExist(),
                  ),
                ),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple),
                  onPressed: () {
                    selectFile();
                  },
                  icon: const Icon(Icons.add_a_photo),
                  label: const Text('Add Photo'),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: firstnamecontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.person,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter First Name',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                   Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: lastnamecontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.person,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Last Name',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                   Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: gendercontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.transgender,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Gender',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                   Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: addresscontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.location_on,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Address',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                 Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: phonenumcontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.mobile_friendly,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Phone Number',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                 Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: birthdaycontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.cake,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Birthday',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                 Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: emailcontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon( 
                        Icons.email,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Email',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
               Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    obscureText: true,
                    controller: passwordcontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.lock,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Password',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                Container(
                  width: double.infinity,
                  height: 100,
                  padding: const EdgeInsets.all(20),
                  child: ElevatedButton(
                    onPressed: () {
                      bool flag = true;
                      if (firstnamecontroller.text == "") {
                         flag = false;
                      }
                      if(birthdaycontroller.text == ""){
                        flag = false;
                        }
                        if (flag) {
                            if(lastnamecontroller.text == ""){
                        flag = false;
                          if(addresscontroller.text == ""){
                        flag = false;    
                      }
                      }
                	        registerUser();
                          uploadFile();
                          error;
                      }
                      else{
                        showDialog(context: context, builder: (context){
                          return  AlertDialog(
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(32))
                            ),
                            backgroundColor: const Color(0XFFC72C41),
                            content: Container(
                              padding: const EdgeInsets.all(16),
                              height: 90,
                              decoration: const BoxDecoration(
                                color: Color(0xFFC72C41),
    
                              ),
                              child: Row(
                                children: [
                                     const Icon(Icons.info,
                                     color: Colors.white,
                                     size: 50,),
                                  Row(                                  
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children:  [
                                      Padding(
                                        padding: const EdgeInsets.only(left: 20),
                                        child: Column(
                                          children: const [
                                            SafeArea(
                                              child: Text("Oh Snap!",style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 17,
                                              fontWeight: FontWeight.bold
                                                                  ),),
                                            ),
                                                                
                                                            SafeArea(
                                                              child: Text('Something Went Wrong',
                                                              style: TextStyle(
                                                                                              color: Colors.white,
                                                                                              fontSize: 10,
                                                              ),
                                                              maxLines: 2,
                                                              overflow: TextOverflow.ellipsis,
                                                              ),
                                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),);
                        },
                        );
                      }
                      setState(() {});
                    },
                    
                   style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.deepPurple),
  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
    RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(200 ),
      side: BorderSide(color: Colors.deepPurple),
    )
  )
),
                    child: const Text(
                      'REGISTER',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget imgExist() => Image.file(
        File(pickedFile!.path!),
        width: double.infinity,
        height: 250,
        fit: BoxFit.cover,
      );

  Widget imgNotExist() => Image.asset(
        'assets/images/no-image-icon-md.png',
        fit: BoxFit.cover,
      );
       Future registerUser() async {
   

    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: emailcontroller.text.trim(),
        password: passwordcontroller.text.trim(),
      );
        QuickAlert.show(
                        context: context,
                        type: QuickAlertType.success,
                         text: 'Added Successfully!',
                         backgroundColor: Colors.deepPurple
                            );

      setState(() {
        error = "";
      });
    } on FirebaseAuthException catch (e) {
      print(e);
      setState(() {
        error = e.message.toString();
      });
    }

  }

  Future createUser(urlDownload) async {
    final docUser = FirebaseFirestore.instance.collection('PracUser').doc();

    final newUser = Users1(
      id: docUser.id,
      lastname: lastnamecontroller.text,
      phonenum: phonenumcontroller.text,
      email: emailcontroller.text,
      password: passwordcontroller.text,
      firstname: firstnamecontroller.text,
      gender: gendercontroller.text,
      address: addresscontroller.text,
      birthday: birthdaycontroller.text,
      image: urlDownload,
    );

    final json = newUser.toJson();
    await docUser.set(json);

    setState(() {
      lastnamecontroller.text = "";
      phonenumcontroller.text = "";
      passwordcontroller.text = "";
      firstnamecontroller.text = "";
      gendercontroller.text = "";
      addresscontroller.text = "";
      birthdaycontroller.text = "";
      emailcontroller.text = "";
      pickedFile = null;
    });
  }
   Widget buildProgress() => StreamBuilder<TaskSnapshot>(
      stream: uploadTask?.snapshotEvents,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          final data = snapshot.data!;
          double progress = data.bytesTransferred / data.totalBytes;

          return SizedBox(
            height: 50,
            child: Stack(
              fit: StackFit.expand,
              children: [
                LinearProgressIndicator(
                  value: progress,
                  backgroundColor: Colors.grey,
                  color: Colors.deepPurple,
                ),
                Center(
                  child: Text(
                    '${(100 * progress).roundToDouble()}%',
                    style: const TextStyle(
                      color: Colors.white,
                    ),
                  ),
                )
              ],
            ),
          );
        } else {
          return const SizedBox(
            height: 50,
          );
        }
      }
      );
 
}
