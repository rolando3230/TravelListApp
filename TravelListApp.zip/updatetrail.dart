import 'dart:io';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:huhu/additem.dart';
import 'package:huhu/user1.dart';
import 'package:quickalert/models/quickalert_type.dart';
import 'package:quickalert/widgets/quickalert_dialog.dart';



class UpdateTrail extends StatefulWidget {
  const UpdateTrail({
    super.key,
    required this.user,
  });

  final UserPost user;

  @override
  State<UpdateTrail> createState() => _UpdateTrailState();
}

class _UpdateTrailState extends State<UpdateTrail> {
  late TextEditingController trailnamecontroller;
  late TextEditingController locationcontroller;
  late TextEditingController descriptioncontroller;
  late TextEditingController traildurationcontroller;
  late TextEditingController traildistancecontroller;
  late TextEditingController trailtypecontroller;
  late String imgUrl;
  late String error;
  PlatformFile? pickedFile;
  UploadTask? uploadTask;

  Future selectFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result == null) return;

    setState(() {
      pickedFile = result.files.first;
    });
  }

  String generateRandomString(int len) {
    var r = Random();
    const _chars =
        'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';
    return List.generate(len, (index) => _chars[r.nextInt(_chars.length)])
        .join();
  }

  Future uploadFile() async {
    final path = 'files/${generateRandomString(8)}';
    print('update path Link: $path');
    final file = File(pickedFile!.path!);

    final ref = FirebaseStorage.instance.ref().child(path);

    try {
      setState(() {
        uploadTask = ref.putFile(file);
      });
    } on FirebaseException catch (e) {
      setState(() {
        error = e.message.toString();
      }); 
      
    }

    final snapshot = await uploadTask!.whenComplete(() {});
    final urlDownload = await snapshot.ref.getDownloadURL();
    print('update Download Link: $urlDownload');

    updateUser(widget.user.id, urlDownload);

    setState(() {
      uploadTask = null;
    });
    
  }

  @override
  void initState() {
    super.initState();
    trailnamecontroller = TextEditingController(
      text: widget.user.trailname,
    );
    locationcontroller = TextEditingController(
      text: widget.user.location,
    );
    descriptioncontroller = TextEditingController(
      text: widget.user.description,
    );
    traildurationcontroller = TextEditingController(
      text: widget.user.trailduration,
    );
     traildistancecontroller = TextEditingController(
      text: widget.user.traildistance,
    );
     trailtypecontroller = TextEditingController(
      text: widget.user.trailtype,
    );

    imgUrl = widget.user.image;
    error = "";
  }

  @override
  void dispose() {
    trailnamecontroller.dispose();
    locationcontroller.dispose();
    descriptioncontroller.dispose();
    traildurationcontroller.dispose();
    traildistancecontroller.dispose();
    trailtypecontroller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: const Padding(
          padding: EdgeInsets.only(left: 20),
          child: Text('Update Trail List',
          style: TextStyle(
            fontSize: 25,
            fontWeight: FontWeight.bold
          ),),
        ),
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            size: 35,
            Icons.arrow_back,
          ),
        ),
      ),
      backgroundColor: Colors.grey.shade300,
      body: ListView(
        children: [
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(
                  height: 20,
                ),
                Container(
                  margin: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    border: Border.all(
                      width: 2,
                      color: Color.fromARGB(142, 158, 158, 158),
                    ),
                  ),
                  child: Center(
                    child: (pickedFile == null) ? checkImgVal() : imgExist(),
                  ),
                ),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple),
                  onPressed: () {
                    selectFile();
                  },
                  icon: const Icon(Icons.camera),
                  label: const Text('Add Photo'),
                ),
                const SizedBox(
                  height: 20,
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    maxLines: 5,
                    controller: descriptioncontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.description,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Description',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: trailnamecontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.hiking,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Trail Name',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                 Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: traildurationcontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.timer_outlined,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Trail Duration',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: trailtypecontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.type_specimen,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Trail Type',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                 Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: locationcontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.location_on_rounded,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Location',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                  Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: TextFormField(
                    controller: traildistancecontroller,
                    decoration: const InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepPurple),
                        borderRadius: BorderRadius.all(Radius.circular(20))
                      ),
                      prefixIcon: Icon(
                        Icons.map,
                        color: Colors.deepPurple,
                      ),
                      labelText: 'Enter Trail Distance',
                      labelStyle: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.grey,
                    ),
                  ),
                ),
                Container(
                  width: double.infinity,
                  height: 100,
                  padding: const EdgeInsets.all(20),
                  child: ElevatedButton(
                    onPressed: () {
                      (pickedFile != null)
                          ? uploadFile()
                          : updateNoFile(widget.user.id);
                          error;
                         
                
                    },
                    style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.deepPurple),
  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
    RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(200 ),
      side: BorderSide(color: Colors.deepPurple),
    )
  )
),
                    child: const Text(
                      'Update',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(20),
                  child: Text(
                    error,
                    style: const TextStyle(
                      color: Colors.red,
                    ),
                  ),
                ),
                buildProgress()
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future updateUser(String id, String image) async {
    final docUser = FirebaseFirestore.instance.collection('UserPost').doc(id);
    await docUser.update({
      'trailduration': traildurationcontroller.text,
      'trilname': trailnamecontroller.text,
      'phonenum': locationcontroller.text,
      'description': descriptioncontroller.text,
      'trailtype': trailtypecontroller.text,
      'traildistance': traildistancecontroller.text,
      'location': locationcontroller.text,
      'image': image,
    });
     QuickAlert.show(
                        context: context,
                        type: QuickAlertType.success,
                         text: 'Edited  Successfully',
                         backgroundColor: Colors.deepPurple
                            );
  }

  Future updateNoFile(String id) async {
    final docUser = FirebaseFirestore.instance.collection('UserPost').doc(id);
    await docUser.update({
     'trailduration': traildurationcontroller.text,
      'trailname': trailnamecontroller.text,
      'phonenum': locationcontroller.text,
      'description': descriptioncontroller.text,
      'trailtype': trailtypecontroller.text,
      'traildistance': traildistancecontroller.text,
      'location': locationcontroller.text,
    }); 
    QuickAlert.show(
                        context: context,
                        type: QuickAlertType.success,
                         text: 'Edited  Successfully',
                         backgroundColor: Colors.deepPurple
                            );
  }

  Widget imgExist() => Image.file(
        File(pickedFile!.path!),
        width: double.infinity,
        height: 250,
        fit: BoxFit.cover,
      );

  Widget imgNotExist() => Image.network(
        widget.user.image,
        width: double.infinity,
        height: 250,
        fit: BoxFit.cover,
      );

  Widget imgNotExistBlank() => Image.asset(
        'assets/images/no-image.png',
        width: double.infinity,
        height: 250,
        fit: BoxFit.cover,
      );

  Widget checkImgVal() {
    return (widget.user.image == '-') ? imgNotExistBlank() : imgNotExist();
  }

  Widget buildProgress() => StreamBuilder<TaskSnapshot>(
      stream: uploadTask?.snapshotEvents,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          final data = snapshot.data!;
          double progress = data.bytesTransferred / data.totalBytes;

          return SizedBox(
            height: 50,
            child: Stack(
              fit: StackFit.expand,
              children: [
                LinearProgressIndicator(
                  value: progress,
                  backgroundColor: Colors.grey,
                  color: Colors.deepPurple,
                ),
                Center(
                  child: Text(
                    '${(100 * progress).roundToDouble()}%',
                    style: const TextStyle(
                      color: Colors.white,
                    ),
                  ),
                )
              ],
            ),
          );
        } else {
          return const SizedBox(
            height: 50,
          );
        }
      });
}
